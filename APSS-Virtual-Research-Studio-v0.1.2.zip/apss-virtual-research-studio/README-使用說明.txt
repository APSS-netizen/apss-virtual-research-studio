APSS Virtual Research Studio v0.1.2
修正內容：
1. 修正第二席位未正常可見的問題。
2. 重新調整四席位座標，讓四位研究員都能穩定顯示。

APSS Virtual Research Studio v0.1.1｜Windows 11 使用說明

修正：v0.1 畫面中央空白。原因是 3D 投影函式誤用了不存在的 camera.y，
已更正為 camera.yaw。無須安裝 Node.js 或 Git。

開啟方法：
1. 將 ZIP 完整解壓縮到 Windows「下載」或桌面資料夾。
2. 雙擊 apss-virtual-research-studio\index.html。
3. 使用 Chrome 或 Edge 開啟。
4. 中央應顯示辦公室地板、四組辦公桌及虛擬研究員；滑鼠可旋轉或滾輪縮放。

注意：
- 此版為獨立、離線的示範介面；所有研究員狀態均為模擬。
- 四項 MR 真實排程、執行日誌與通知系統均未介接。
- 本機待辦事項使用瀏覽器 localStorage 儲存，開啟不同檔案路徑可能不會沿用舊資料。
- 可在舊版先點右上角「匯出本機資料」備份待辦清單。
- 如更新後仍顯示舊畫面，確認網址指向 v0.1.1 資料夾並按 Ctrl+F5。
